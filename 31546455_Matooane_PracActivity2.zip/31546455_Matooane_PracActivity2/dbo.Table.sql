﻿CREATE TABLE [dbo].[Table]
(
	[Meal Code] INT NULL PRIMARY KEY, 
    [Meal] NVARCHAR(MAX) NULL, 
    [Price] NUMERIC NULL
)
