﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _315464555_PD_MATOOANE_PracActivity4
{
    public partial class Form2 : Form
    {
        private SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Desktop\31546455_PD_MATOOANE_PracActivity4\315464555_PD_MATOOANE_PracActivity4\Database1.mdf;Integrated Security=True");
        private DataTable dt = new DataTable();

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            LoadData();
            PopulateBrandComboBox();
        }

        private void LoadData()
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM [Table]", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                dt.Clear();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void PopulateBrandComboBox()
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT DISTINCT Brand FROM [Table]", con);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    comboBox1.Items.Add(reader["Brand"].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string filterExpression = "";

                if (!string.IsNullOrEmpty(textBox1.Text))
                {
                    filterExpression = $"ProductName LIKE '%{textBox1.Text}%'";
                }

                if (comboBox1.SelectedItem != null)
                {
                    if (!string.IsNullOrEmpty(filterExpression))
                        filterExpression += " AND ";
                    filterExpression += $"Brand = '{comboBox1.SelectedItem}'";
                }

                DataView dv = dt.DefaultView;
                dv.RowFilter = filterExpression;
                dataGridView1.DataSource = dv.ToTable();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LoadData();
            textBox1.Text = "";
            comboBox1.SelectedIndex = -1;
        }
    }
}
