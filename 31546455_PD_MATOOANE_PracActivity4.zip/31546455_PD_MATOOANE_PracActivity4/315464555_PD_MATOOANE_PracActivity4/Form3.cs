﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _315464555_PD_MATOOANE_PracActivity4
{
    public partial class Form3 : Form
    {
        private SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Desktop\31546455_PD_MATOOANE_PracActivity4\315464555_PD_MATOOANE_PracActivity4\Database1.mdf;Integrated Security=True");

        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Check if ProductID is empty
                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    MessageBox.Show("Please enter a Product ID.");
                    return;
                }

                // Check if Price is empty or not a valid decimal
                decimal price;
                if (!decimal.TryParse(textBox4.Text, out price))
                {
                    MessageBox.Show("Please enter a valid price.");
                    return;
                }

                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO [Table] (ProductID, ProductName, Brand, Price) VALUES (@ProductID, @ProductName, @Brand, @Price)", con);
                cmd.Parameters.AddWithValue("@ProductID", textBox1.Text);
                cmd.Parameters.AddWithValue("@ProductName", textBox2.Text);
                cmd.Parameters.AddWithValue("@Brand", textBox3.Text);
                cmd.Parameters.AddWithValue("@Price", price);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Product added successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                // Check if ProductID is empty
                if (string.IsNullOrWhiteSpace(textBox5.Text))
                {
                    MessageBox.Show("Please enter a Product ID.");
                    return;
                }

                // Check if ProductID is not a valid integer
                int selectedProductID;
                if (!int.TryParse(textBox5.Text, out selectedProductID))
                {
                    MessageBox.Show("Please enter a valid Product ID.");
                    return;
                }

                con.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM [Table] WHERE ProductID = @ProductID", con);
                cmd.Parameters.AddWithValue("@ProductID", selectedProductID);
                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Product deleted successfully.");
                }
                else
                {
                    MessageBox.Show("Product with provided ID not found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
