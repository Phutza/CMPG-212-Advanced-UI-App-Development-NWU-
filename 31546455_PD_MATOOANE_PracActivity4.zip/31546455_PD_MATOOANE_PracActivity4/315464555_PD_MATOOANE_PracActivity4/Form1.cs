﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _315464555_PD_MATOOANE_PracActivity4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void listToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 viewfrm = new Form2(); // Create new instance for the form
            viewfrm.MdiParent = this; // linking to the parent
            viewfrm.Show(); // Display child
        }

        private void editProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
         
        }

        private void insertAndDeleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 Vieweditfrm = new Form3();
            Vieweditfrm.MdiParent = this;
            Vieweditfrm.Show(); // Display child
        }
    }
}
