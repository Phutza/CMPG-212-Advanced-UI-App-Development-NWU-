﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PracActivity1_31546455
{
    public partial class Form1 : Form
    {
        private string conStr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=\\143.160.81.13\CTX_Redirected_Data$\31546455\Deskop\Practical_Activity_1_31546455_PD_MATOOANE\PracActivity1_31546455\Database1.mdf;Integrated Security=True";
        private SqlConnection conne;
        private SqlCommand comm;
        private SqlDataAdapter adt;
        private DataSet Ds;
        private SqlDataReader TheReader;

        public Form1()
        {
            InitializeComponent();
        }

        private void ConnectDB_Click(object sender, EventArgs e)
        {
            try
            {
                conne = new SqlConnection(conStr);
                conne.Open();
                conne.Close();
                MessageBox.Show("Connection successful");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Read_Click(object sender, EventArgs e)
        {
            try
            {
                conne.Open();
                string sql = "SELECT * FROM StudentTable";
                comm = new SqlCommand(sql, conne);
                TheReader = comm.ExecuteReader();

                while (TheReader.Read())
                {
                    listBox1.Items.Add(TheReader.GetValue(0) + "\t" + TheReader.GetValue(1) + "\t" + TheReader.GetValue(2) + "\t" + TheReader.GetValue(3) + "\t" + TheReader.GetValue(4));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conne.Close();
            }
        }

        private void Insert_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conne = new SqlConnection(conStr))
                {
                    conne.Open();

                    // Initialize the DataSet if not already initialized
                    if (Ds == null)
                    {
                        Ds = new DataSet();
                    }

                    // Check if the DataTable "StudentTable" exists in the DataSet
                    DataTable studentTable = Ds.Tables["StudentTable"];
                    if (studentTable == null)
                    {
                        // If not, create the DataTable
                        studentTable = new DataTable("StudentTable");
                        Ds.Tables.Add(studentTable);
                    }

                    // Assuming you have a DataTable named "StudentTable" in the DataSet
                    DataRow newRow = studentTable.NewRow();
                    newRow["Name"] = "New Name";
                    newRow["Surname"] = "New Surname";
                    newRow["StudentCode"] = "New StudentCode";

                    studentTable.Rows.Add(newRow);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Update_Click(object sender, EventArgs e)
        {
            try
            {
                conne = new SqlConnection(conStr);
                conne.Open();

                adt = new SqlDataAdapter("SELECT * FROM StudentTable", conne);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(adt);

                adt.UpdateCommand = commandBuilder.GetUpdateCommand();
                adt.Update(Ds.Tables["StudentTable"]);

                MessageBox.Show("Records updated successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conne.Close();
            }
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                    int studentId = (int)dataGridView1.Rows[selectedRowIndex].Cells["StudentId"].Value;
                    string sql = $"DELETE FROM StudentTable WHERE StudentId = {studentId}";

                    conne = new SqlConnection(conStr);
                    conne.Open();
                    SqlCommand SqlComm = new SqlCommand(sql, conne);
                    SqlComm.ExecuteNonQuery();
                    MessageBox.Show("Record deleted successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Please select a row to delete", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conne.Close();
            }
        }

        private void Display_Click(object sender, EventArgs e)
        {
            try
            {
                conne.Open();
                adt = new SqlDataAdapter();
                Ds = new DataSet();
                string sql = "SELECT * FROM StudentTable"; // Correct SQL syntax
                comm = new SqlCommand(sql, conne);
                adt.SelectCommand = comm;
                adt.Fill(Ds, "StudentTable"); // Assuming the table name is StudentTable
                dataGridView1.DataSource = Ds;
                dataGridView1.DataMember = "StudentTable";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conne.Close();
            }
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
