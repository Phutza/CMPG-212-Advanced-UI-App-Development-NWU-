﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _31546455_PracActivity3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //dECLARE vARIABLES
        string conStr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\User\Music\31546455_PD_Matooane_PracActivivty3\31546455_PracActivity3\Database1.mdf;Integrated Security=True";
        
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You are about to exit");
            Application.Exit();//exit the application
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

            Form2 viewfrm = new Form2(); // Create new instance for the form
            viewfrm.MdiParent = this; // linking to the parent
            viewfrm.Show(); // Display child
        }
    }
}
